numero = int(input("Ingrese el número que se elevará al cubo: "))
cubo = numero**3
print("El resultado es: ", cubo)

