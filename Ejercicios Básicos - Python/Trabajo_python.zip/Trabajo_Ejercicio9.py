salario = float(input("Ingrese el salario del empleado: "))
impuesto = 6
total1 = 0
total2 = 0
total3 = 0
total = salario-(salario*6/100)
total2= salario-total

print("Su salario es ", salario , " y  le descontará el 6% que viene a ser :", total2)
print("Su salario ahora es: ", total)
      
