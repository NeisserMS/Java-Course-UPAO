Python 3.7.3 (v3.7.3:ef4ec6ed12, Mar 25 2019, 21:26:53) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> descuento = 35
>>> costo = 100
>>> total = 0
>>> total = costo-(costo*35/100)
>>> print("El costo de la medicina es:",total)
El costo de la medicina es: 65.0
>>> 
