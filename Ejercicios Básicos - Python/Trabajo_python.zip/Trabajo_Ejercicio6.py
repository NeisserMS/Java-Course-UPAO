Python 3.7.3 (v3.7.3:ef4ec6ed12, Mar 25 2019, 21:26:53) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> #Escriba un algoritmo que dada la cantidad de monedas de 1,2 y 5 soles y los billetes de 10 , 20, 50 y 100 soles, diga la cantidad de dinero que se tiene en total.
>>> moneda1 = 1
>>> moneda2 = 2
>>> moneda3 = 5
>>> billete1 = 10
>>> billete2 = 20
>>> billete3 = 50
>>> billete4 = 100
>>> billete5 = 200
>>> total1 = 0
>>> total2 = 0
>>> total3 = 0
>>> total1 = moneda1 + moneda2 + moneda3
>>> total2 = billete1 + billete2 + billete3 + billete4 + billete5
>>> total3 = total1 + total2
>>> print("La cantidad de dinero que se tiene es:", total3)
La cantidad de dinero que se tiene es: 388
>>> 
