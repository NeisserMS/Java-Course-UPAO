numero1 = int(input("Ingrese el primer número positivo: "))
numero2 = int(input("Ingrese el segundo número positivo: "))
suma = 0
multiplicacion = 0
suma = numero1 + numero2
multiplicacion = numero1*numero2
print("La suma de los dos números es: ", suma)
print("La multiplicacion de los dos numeros es: ", multiplicacion)
