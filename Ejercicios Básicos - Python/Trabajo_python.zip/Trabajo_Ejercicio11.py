A = int(input("Ingrese el primer número: "))
B = int(input("Ingrese el segundo número: "))
C = int(input("Ingrese el tercer número: "))
x = 0 


x =  A,B,C

print("Los 3 números son: ", x)
