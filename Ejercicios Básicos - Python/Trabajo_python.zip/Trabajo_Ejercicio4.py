Python 3.7.3 (v3.7.3:ef4ec6ed12, Mar 25 2019, 21:26:53) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> salario = 1000
>>> incremento = 8
>>> 
>>> total = 1000*8/100+1000
>>> print("Su nuevo salario es:",total)
Su nuevo salario es: 1080.0
>>> 
