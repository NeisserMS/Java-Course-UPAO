ancho = float(input("Ingrese el ancho de la pared: "))
largo = float(input("Ingrese el largo de la Pared: "))
area = ancho*largo
arena = area*0.125
print("El area de la Pared es: ", area)
print("Los metros cubicos de arena que se usaran son: ", arena)
 
