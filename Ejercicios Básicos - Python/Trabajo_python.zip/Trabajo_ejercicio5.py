Python 3.7.3 (v3.7.3:ef4ec6ed12, Mar 25 2019, 21:26:53) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> urgencia = 37
>>> pediatria = 42
>>> traumatologia = 21
>>> presupuesto = 1000

>>> total1 = presupuesto*37/100
>>> total2 = presupuesto*42/100
>>> total3 = presupuesto*21/100
>>> print("La cantidad de dinero que recibirá Pediatria es:", total2)
La cantidad de dinero que recibirá Pediatria es: 420.0
>>> print("La cantidad de dinero que recibirá Urgencias es:", total1)
La cantidad de dinero que recibirá Urgencias es: 370.0
>>> print("La cantidad de dinero que recibirá Traumatologia es:", total3)
La cantidad de dinero que recibirá Traumatologia es: 210.0
>>> 
