pulgada = float(input("Ingrese el número de Pulgadas: "))
centimetro = 0
centimetro = pulgada*0.39737/1
print("Las pulgadas del numero ", pulgada , " en centimetros es: ", centimetro)
