Python 3.7.3 (v3.7.3:ef4ec6ed12, Mar 25 2019, 21:26:53) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> tiempo = 5
>>> costo = 1.5
>>> total = tiempo*costo
>>> print("El monto a pagar es:", total)
El monto a pagar es: 7.5
>>> 
