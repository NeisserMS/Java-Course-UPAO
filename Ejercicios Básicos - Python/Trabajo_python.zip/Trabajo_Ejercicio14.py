parcial1 = int(input("Ingrese la nota del primer examen parcial: "))
parcial2 = int(input("Ingrese la nota del segundo examen parcial: "))
parcial3 = int(input("Ingrese la nota del tercer examen parcial: "))
promedio = 0
promedio = (parcial1+parcial2+parcial3)/3
print("El promedio final es: ", promedio)
