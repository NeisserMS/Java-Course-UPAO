salario_anterior = float(input("Ingrese el salario Anterior del obrero: "))


nuevo_salario = (salario_anterior*0.25)+salario_anterior
print("Su incremento en su nuevo salario es 25%")
print("Su salario nuevo es: ", nuevo_salario)
