distancia = float(input("Ingrese la distancia en metros: "))
pies = 0.3048
pulgadas = 0.0254

pies = distancia*(3.28/1)
pulgadas = distancia*(39.37/1)
print("La distancia ", distancia , " en pies es " , pies , "y en pulgadas " , pulgadas)
