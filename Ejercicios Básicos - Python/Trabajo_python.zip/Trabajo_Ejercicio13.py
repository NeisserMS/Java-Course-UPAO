
print("---Cuadrado---")
lado = int(input("Ingrese el tamaño del lado: "))
perimetro = 0
area = 0
perimetro = lado*4
area = lado*lado
print("El perimetro del cuadrado es: ", perimetro)
print("El area del cuadrado es: ", area)


