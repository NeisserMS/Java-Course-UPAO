A = int(input("Ingrese el número de años: "))
M = int(input("Ingrese el número de meses: "))
T = 0
T = A*12+M
print("Su edad en meses es: ", T)
