a = 5
b = 3
suma = 2*a + b**2
promedio = (a**3+b**3)/2
print("La suma es: ", suma)
print("El promedio es: ", promedio)
